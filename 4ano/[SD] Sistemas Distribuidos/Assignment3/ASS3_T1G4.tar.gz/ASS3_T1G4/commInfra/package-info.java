/**
 *   Common infrastructure.
 *
 *    Implementation of a client-server model of type 2 (server replication).
 *    Communication is based on Java RMI.
 */
package commInfra;
