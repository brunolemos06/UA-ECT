/**
 *  Interfaces to remote objects for the Assault problem.
 *
 *    Communication is based on Java RMI.
 */

 package interfaces;