var group___db_c =
[
    [ "dbc.h", "dbc_8h.html", null ],
    [ "check", "group___db_c.html#gac101c8ba449f6f8c71b3789a9c489221", null ],
    [ "require", "group___db_c.html#ga5bf1825f80465097d4b753a001cf1af8", null ],
    [ "ensure", "group___db_c.html#ga5d17c602c4f191371a5fec5af7adc3cf", null ],
    [ "invariant", "group___db_c.html#gaf9d59b04beef1bf139e10fc44c6f9725", null ]
];